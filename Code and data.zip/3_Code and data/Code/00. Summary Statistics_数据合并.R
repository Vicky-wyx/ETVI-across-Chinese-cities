###-----------------------------------------------------------####
###-----------------------------------------------------------####
####-----------------ETVI: 城市级数据构建---------------------####
###-----------------------------------------------------------####
###-----------------------------------------------------------####


#remove all the things

rm(list=ls(all=TRUE)) 

#Set workspace
getwd()
setwd("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code")

#Sys.setlocale(category="LC_ALL",locale="en_US.UTF-8")
#Packages
library(readxl)
library(moments)
library(dplyr)
library(ggplot2)
library(poweRlaw)
library(tidyverse)
#load the data

#Sys.setlocale(category = "LC_ALL", locale = "zh_cn.utf-8") #-------------------------------------------------------Read the Data

#-------------------
#-------------------
#01. 读取CEADs数据
#-------------------
#-------------------

Data_电力<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/2023_energy inputs for power.xlsx")
Data_电力=select(Data_电力,city,year,`总和（共18种）104吨标准煤`)
colnames(Data_电力)=c("城市","年份","发电能耗（万吨标准煤）")


Data_能源燃烧量<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/2023_energy vector(NCV).xlsx")
Data_能源燃烧量=select(Data_能源燃烧量,city,year,Scope_1_Total,`能源结构`)
colnames(Data_能源燃烧量)=c("城市","年份","Scope 1 Total能源燃烧量（NCV)","能源结构")


Data_碳排放<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/2023_碳排放.xlsx")
Data_碳排放=select(Data_碳排放,city,year,`carbon emssion`)
colnames(Data_碳排放)=c("城市","年份","各城市排放量")

#-------------------
#01.1 合并数据
#-------------------

Data_temp=merge(Data_电力,Data_能源燃烧量,by=c("城市"="城市","年份"="年份"),all=F)

Data_temp=merge(Data_temp,Data_碳排放,by=c("城市"="城市","年份"="年份"),all=F)

#-------------------
#01.2 去除negative的电力数据
#-------------------

Data_temp <- Data_temp[Data_temp$`发电能耗（万吨标准煤）`>= 0, ]

#-------------------
#01.3 在城市后面加“市”
#-------------------
Data_temp$shi<-c('市')
Data_temp$城市<-str_c(Data_temp$城市, Data_temp$shi)
Data_temp <-select (Data_temp, -shi)

#-------------------
#-------------------
#02. 读取城市数据
#-------------------
#-------------------

#a. 读取baseline城市数据
Data_city<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_data_Shen_2022_12_21.xlsx")

#b. 读取填充数据,命名为城市数据_2
Data_city_2<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_data_2.xlsx")
Data_city_2_其他=select(Data_city_2,"城市","年份","固定资产净值年平均余额_全市_万元","年末金融机构人民币各项存款余额_全市_万元","外商实际投资额_全市_万美元","科研综合技术服务业从业人员数_全市_人")

#用电量2016年之后数据不对，删去相关数据
Data_city_2_电力=select(Data_city_2,"城市","年份","全年用电总量_市辖区_万千瓦时")
Data_city_2_电力=filter(Data_city_2_电力,年份<2017)
Data_city_2=merge(Data_city_2_电力,Data_city_2_其他,by=c("城市"="城市","年份"="年份"),all=T)

#c. 读取填充数据,原始文档，命名为城市数据_3
Data_city_3<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_data_原始文档.xlsx")
Data_city_3=select(Data_city_3,"城市","年份","普通本专科在校学生数_全市_人")

#d. 选取baseline城市数据中的普通本专科数据，之后将与city_3合并
Data_city_4<-select(Data_city,"城市","年份","普通本专科在校学生数_人_全市")


#-------------------
#02.1 合并Data_city_3,Data_city_4
#-------------------

Data_city_3=merge(Data_city_3,Data_city_4,by=c("城市"="城市","年份"="年份"),all=T)

Data_city_3$普通本专科在校学生人数=pmax(Data_city_3$普通本专科在校学生数_全市_人,Data_city_3$普通本专科在校学生数_人_全市,na.rm = TRUE)
Data_city_3<-select(Data_city_3,"城市","年份","普通本专科在校学生人数")


#-------------------
#02.1 合并数据
#-------------------

#合并Data_city_2数据
Data_city=merge(Data_city,Data_city_2,by=c("城市"="城市","年份"="年份"),all=T)

#合并Data_city_3数据
Data_city=merge(Data_city,Data_city_3,by=c("城市"="城市","年份"="年份"),all=T)

#合并能源环境数据
Data=merge(Data_city,Data_temp,by=c("城市"="城市","年份"="年份"),all=T)

#-------------------
#02.2 选择282个城市
#-------------------

City_list<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_list.xlsx")

Data=filter(Data,城市 %in% City_list$城市) 


#-------------------
#-------------------
#03. 读取创新数据
#-------------------
#-------------------

City_innovation_1<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/2023_各省市绿色专利申请情况.xlsx")
City_innovation_1=select(City_innovation_1,城市,年份,当年申请的绿色发明数量,当年申请的绿色实用新型数量)
colnames(City_innovation_1)=c("城市","年份","当年申请的绿色发明数量","当年申请的绿色实用新型数量")


City_innovation_2<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/2023_年中国区域创新创业指数.xlsx")
City_innovation_2=select(City_innovation_2,城市,年份,人均得分)
colnames(City_innovation_2)=c("城市","年份","人均得分")

#-------------------
#03.1 合并数据
#-------------------

Data_temp=merge(City_innovation_1,City_innovation_2,by=c("城市"="城市","年份"="年份"),all=T)

Data_temp=merge(Data,Data_temp,by=c("城市"="城市","年份"="年份"),all=T)


#-------------------
#-------------------
#04. 读取PM2.5数据
#-------------------
#-------------------

City_PM25<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/地市PM2.5数据合并（2000-2018）.xlsx",sheet="整理后")

city_code<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_code.xlsx")

City_PM25 = filter(City_PM25,市代码 %in% city_code$行政区划代码)


#填充缺失的城市名称
for (i in 1:dim(City_PM25)[1]) {
  City_PM25$城市[i]<-city_code$城市[city_code$行政区划代码==City_PM25$市代码[i]]
}

City_PM25=select(City_PM25,城市,年份,PM2.5)


Data_temp=merge(Data_temp,City_PM25,by=c("城市"="城市","年份"="年份"),all=T)

#-------------------
#-------------------
#05. 读取贫困及老龄化数据
#-------------------
#-------------------

City_proverty<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/贫困率和老龄化率.xlsx")

Data_temp=merge(Data_temp,City_proverty,by=c("城市"="城市","年份"="年份"),all=T)

#-------------------
#-------------------
#06. 读取能源依赖程度数据
#-------------------
#-------------------


#-------------------
#-------------------
#07. 选择数据
#-------------------
#-------------------


#-------------------
#07.1 选择282个城市
#-------------------

City_list<-read_excel("C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/data/City_list.xlsx")

Data_select=filter(Data_temp,城市 %in% City_list$城市) 


#-------------------
#07.2 选择2003年之后，2020年之前数据
#-------------------
Data_select=filter(Data_select,年份>2002)
Data_select=filter(Data_select,年份<2020)

#------------------------------------
####save the data
#------------------------------------

write.csv(Data_select, "C:/Users/TJSEM/Dropbox/00000_1_Idea List/Idea_7_Energy_Transition_Justice_城市/3_Code/Data.xlsx")