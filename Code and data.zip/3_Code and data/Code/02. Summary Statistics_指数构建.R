###-----------------------------------------------------------####
###-----------------------------------------------------------####
####----------------ETVI: 城市级数据构建----------------------####
###-----------------------------------------------------------####
###-----------------------------------------------------------####


#remove all the things
rm(list=ls(all=TRUE)) 

# Sys.setenv(JAVA_HOME = "C:/Program Files/Java/jdk1.8.0_251")  # 修改为你实际安装路径
# 
# library(rJava)
# library(xlsx)
#读取阶段一结果
source("G:/我的云端硬盘/活动工作文件夹/14_ETVI_city/R2/2_Code/3_Code/01. Summary Statistics_数据处理.R")
library(zoo)

#读取城市名称列表
city_name_list <- read_excel("city_name_list.xlsx")

###--------------------
#指数列表： 
###--------------------

#---------------
#01. EXPOSURE
#---------------

####A. Energy Mix：
#A_1_能源结构: 煤炭占比 (%)
#A_2_电力结构: 发电能耗/用电量 (吨标准煤/千瓦时)

####B. Energy Revenue：
#B_1_能源收入: 煤炭产业占比(%)

#---------------
#02. Sensitivity
#---------------

####C. Energy Dependence：  
#C_1_能源消费: 人均能源消费；
#C_2_电力消费：人均电力消费； 

####D. Occupational sectors：  
#D_1_煤炭人口：采掘业人员比例；

####E. Wealth：  
#E_1_贫困人口：贫困人员比例；

####F. susceptible demographics：  
#F_1_失业人口：失业人口比例；
#F_2_老龄人口：老龄人口比例；

#---------------
#03. Adaptive Capacity
#---------------

####G. Economic capacity：  
#G_1_GDP: 人均GDP；

####H. Science & Technology：  
#D_1_R&D expenditure: 科技支出比例
#D_2_R&D人员比例: 研究人员比例
#D_3_专利: 人均专利 

####I. Education & Training：
#I_1_教育 expenditure: 教育支出比例
#I_2_教育人员比例: 教育人员比例
#I_3_高等教育: 高等教育学生（大学生）比例 

####J. Fiscal & governability：
#J_1_公共支出 expenditure: 人均财政支出
#J_2_社会保障支出: 人均社会保障支出
#J_3_固定资产投资支出: 人均固定资产投资支出
#J_4_开放程度: 人均利用外资


###-------------------------------------------------------------------------------------------------------------###
###-------------------------------------------------------------------------------------------------------------###
############################################### Step_2: 数据处理################################################### 
###-------------------------------------------------------------------------------------------------------------###
###-------------------------------------------------------------------------------------------------------------###

#------------------------------------
#------------------------------------
####A. 初步查验数据
#------------------------------------
#------------------------------------

# #初始城市数量---------------282个
# length(unique(Data$城市))
# 
# #Check the number of values
# Data_unit = cbind(Data,temp=matrix(1, nrow(temp), 1)) #构建为1的标记序列
# names(Data_unit)[37] <- "Units"                       #命名为Units
# Data_unit <- subset(Data_unit, !is.na(Data_unit$A_1_能源结构)) #以Carbon_Intensity为基准，查看available的数据
# Data_select<-Data_unit %>% group_by(城市)%>% filter(sum(Units)>1)     #遴选大于阈值10的城市集为180，大于阈值5（1）的城市集为234（252）；2010年有数据的为228；总共有282个城市
# #Number of cities
# length(unique(Data_select$城市)) #大于阈值（10）的城市集城市数量-----------------------------------------------数据良好，10为阈值尚有3/4的数据。
# 
# 
# rm(Data_select,Data_unit) 

#------------------------------------
#------------------------------------
####B. 指数构建
#------------------------------------
#------------------------------------


#------------------------------------
####Step B_0. 时间范围的选择 
#------------------------------------

Data_2=Data

#01. 时间变量的选择（2020 年数据不全，舍弃）

Data_2=filter(Data_2,年份<2020) 


#------------------------------------
####Step B_1. 空间范围的选择 
#------------------------------------

#2019年取消了莱芜市

Data_2=filter(Data_2,!城市=="莱芜市") 

#------------------------------------
####Step B_2. 数据填充；暂时使用最简单的方式（如果有一个数据，就用这个数据填充；如果没有数据，就放均值；未来可以用同省数据填充等方式）
#------------------------------------

Data_select=Data_2

#填充数据，标准为线性填充，边界值由边界值延展；注意其中na.approx函数对只有一个数据的列只会return一个数值，所以这边要写loop调整；
n_country=length(unique(Data_select$城市))
n_year=length(unique(Data_select$年份))
n_column=ncol(Data_select)


#步骤一：线性填充
for (i in 1:n_country) {
  for (j in 4:n_column) {
    if (sum(is.na(Data_select[(i*n_year-n_year+1):(i*n_year),j]))==(n_year-1)) { Data_select[(i*n_year-n_year+1):(i*n_year),j]=mean(as.numeric(unlist(Data_select[(i*n_year-n_year+1):(i*n_year),j])),na.rm = T) } 
    else { if (sum(is.na(Data_select[(i*n_year-n_year+1):(i*n_year),j])) < (n_year-1)) { Data_select[(i*n_year-n_year+1):(i*n_year),j]=na.approx(Data_select[(i*n_year-n_year+1):(i*n_year),j],rule=2) }  } 
  }
}


#步骤二：将某一指标全为NA的，用均值代替
Data_temp=Data_select

Data_mean=Data_temp %>% group_by(年份) %>% summarise_all("mean",na.rm = TRUE) 


#填充数据
n_country=length(unique(Data_temp$城市))
n_year=length(unique(Data_temp$年份))
n_column=ncol(Data_temp)


for (i in 1:n_country) {
  for (j in 4:n_column) {
    if (sum(is.na(Data_temp[(i*n_year-n_year+1):(i*n_year),j]))==(n_year)) {Data_temp[(i*n_year-n_year+1):(i*n_year),j]=as.numeric(unlist(Data_mean[,j])) } 
  }
}

Data_2=Data_temp

####------------######                                                          
####------------######                                                         
####------------######                                                          
####--序列变换--######
####------------######                                                          
####------------######                                                          
####------------######                                                        

#-------------
#01. Energy system
#-------------

#能源消费，取log排除异常值
Data_2$C_1_能源消费=log(Data_2$C_1_能源消费*1000)
Data_2$C_2_电力消费=log(Data_2$C_2_电力消费+1) #+1是因为有两个值为0，昆明2003,；

# 
# #-------------
# #02. Readiness
# #-------------
# 
# #------
# #C. 经济变量
# #------
# 
# Data_2$C_1_Economic_Devlelopment_人均GDP=log(Data_2$C_1_Economic_Devlelopment_人均GDP)

# #------
# #D
# #------
# 
# Data_2$D_1_资本存量_人均固定资产净余额=log(Data_2$D_1_资本存量_人均固定资产净余额)
# Data_2$D_1_资本存量_人均存款余额=log(Data_2$D_1_资本存量_人均存款余额)
# Data_2$D_2_投资_人均固定资产投资=log(Data_2$D_2_投资_人均固定资产投资)
# Data_2$D_2_投资_人均当年使用外资=log(Data_2$D_2_投资_人均当年使用外资)
# Data_2$D_3_财政能力_人均GDP=log(Data_2$D_3_财政能力_人均GDP)
# 
# #------
# #E
# #------
# 
# Data_2$E_2_科学支出=log(Data_2$E_2_科学支出)
# 
# #------
# #F
# #------
# 
# Data_2$F_3_教育水平_人均教育事业费用支出=log(Data_2$F_3_教育水平_人均教育事业费用支出)


#------------------------------------
####Step B_3. 上下限的选择（bound selection）
#------------------------------------
#注：暂时我们用最简单的选法，即最高的2.5%和最低的2.5%

Quan_mat=matrix(0,2,length(Data_2))

#97.5% and 2.5%
for (i in 4:length(Data_2)){
  Quan_mat[1,i]<-quantile(na.omit(Data_2[,i]), 0.975)
  Quan_mat[2,i]<-quantile(na.omit(Data_2[,i]), 0.025)
}

colnames(Quan_mat)=colnames(Data_2)

####------------######                                                          
####------------######                                                         
####------------######                                                             
####-上下界精调-######
####------------######                                                          
####------------######                                                          
####------------######                                                          

#-------------
#01. Energy system
#-------------


#电力结构
Quan_mat[1,5]=2.099740e-03 #2015年六盘水市水平


# ###设置参数，调小sensitivity指标的upper bound，不然有些资源型城市太高，导致结果数值太小
# 
#化石能源消费
Quan_mat[2,7]=0

#电力消费
Quan_mat[2,8]=0

# #贫困率
# Quan_mat[1,10]=60


####------------######                                                          
####------------######                                                          
####------------######                                                          
####-输出上下界-######
####------------######                                                          
####------------######                                                         
####------------######                                                          



#------------------------------------
####Step B_4. 数据标准化（normalization of indicator values）------------------------------------------------------------------------------------调整这里来调整数据覆盖城市范围（#遴选大于阈值10的城市集为180，大于阈值5的城市集为234；2010年有数据的为228；总城市数量包含282个）
#------------------------------------



Data_Normal = Data_2;

#本项目中，均为正向指标
Positive_index=4:length(Data_Normal)


#正向指标
for (i in Positive_index){
  for (j in 1:nrow(Data_2)){
    Data_Normal[j,i]<-(( Data_2[j,i]-Quan_mat[2,i])/(Quan_mat[1,i]-Quan_mat[2,i]))*100
  }
}


#top coding，阈值处理（超过100的为100，小于0的为0）

Data_Normal[Data_Normal<0] <- 0
Data_Normal[Data_Normal>100] <- 100

#加回表头
Data_Normal[,1:3]=Data_2[,1:3]

#去除冗余变量
rm(Data_2,Data_temp,Data_mean,Data_select)

#------------------------------------
####Step B_5. 国家&城市指数的构建
#------------------------------------

##################----------------------------------------------------------------###############
##################----------------------------------------------------------------###############
##################-------------------------选择城市范围---------------------------###############
##################------------------基准结果，大样本(281个城市)-------------------###############
##################----------------------------------------------------------------###############
##################----------------------------------------------------------------###############

#初始城市数量---------------281个
length(unique(Data_Normal$城市))
Data_select=Data_Normal
Data_select$B_1_能源收入=100


##################----------------------------------------------------------------###############
##################--------------------1.国家层面指数构建--------------------------###############
##################----------------------------------------------------------------###############


#----------国家指数的构建------------#------------------------------------（每1年一个指数）

#计算年度加总数据
Data_temp<-Data_select%>% group_by(年份)%>% summarise_all("mean",na.rm = TRUE)   


#-----B 理论框架加总----- （根据具体情况，调整）

#生成子指标
Results_National_2_Exposure=(rowMeans(select(Data_temp[,-1], starts_with("A")))+rowMeans(select(Data_temp[,-1], starts_with("B"))))/2
Results_National_2_Sensitivity=(rowMeans(select(Data_temp[,-1], starts_with("C")))+rowMeans(select(Data_temp[,-1], starts_with("D")))+rowMeans(select(Data_temp[,-1], starts_with("E")))+rowMeans(select(Data_temp[,-1], starts_with("F"))))/4
Results_National_2_Adaptive=(rowMeans(select(Data_temp[,-1], starts_with("G")))+rowMeans(select(Data_temp[,-1], starts_with("H")))+rowMeans(select(Data_temp[,-1], starts_with("I")))+rowMeans(select(Data_temp[,-1], starts_with("J"))))/4

#计算总指数
Results_National_2_ETVI=(Results_National_2_Exposure*Results_National_2_Sensitivity*(100-Results_National_2_Adaptive))^(1/3)

#合并数据
Results_National_2_detail=cbind(Data_temp,Results_National_2_Exposure,Results_National_2_Sensitivity,Results_National_2_Adaptive,Results_National_2_ETVI)

#-----------------
#保存数据
#-----------------
write.csv(Results_National_2_detail, "Results_National_2_detail.csv", fileEncoding = "GBK",row.names = F)

# library("xlsx")
# write.xlsx(Results_National_2_detail, "Results_National_2_detail.xlsx", sheetName = "Sheet1", 
#            col.names = TRUE, row.names = F, append = T)

##################----------------------------------------------------------------###############
##################--------------------2.1.城市层面media---------------------------###############
##################----------------------------------------------------------------###############

#----------城市指数的构建------------#------------------------------------（每5年一个指数）

#定义城市数据，方便操作
Data_select_城市 = Data_select

#标识数据，以便计算中位数
Data_select_城市=Data_select_城市 %>% 
  mutate(mark = case_when(年份 %in% c(2003,2004,2005,2006,2007) ~ 1, 
                          年份 %in% c(2008,2009,2010,2011,2012,2013) ~ 2,
                          年份 %in% c(2014,2015,2016) ~ 3,
                          年份 %in% c(2017,2018,2019) ~ 4
  ))

#计算中位数
Data_temp<-Data_select_城市%>% group_by(城市,mark)%>% summarise_all("median",na.rm = TRUE)   


#-----B 理论框架加总----- （根据具体情况，调整）

#计算中位数
Data_temp<-Data_select_城市%>% group_by(城市,mark)%>% summarise_all("median",na.rm = TRUE)   

#生成子指标
Results_city_2_Exposure=(rowMeans(select(Data_temp[,-1], starts_with("A")))+rowMeans(select(Data_temp[,-1], starts_with("B"))))/2
Results_city_2_Sensitivity=(rowMeans(select(Data_temp[,-1], starts_with("C")))+rowMeans(select(Data_temp[,-1], starts_with("D")))+rowMeans(select(Data_temp[,-1], starts_with("E")))+rowMeans(select(Data_temp[,-1], starts_with("F"))))/4
Results_city_2_Adaptive=(rowMeans(select(Data_temp[,-1], starts_with("G")))+rowMeans(select(Data_temp[,-1], starts_with("H")))+rowMeans(select(Data_temp[,-1], starts_with("I")))+rowMeans(select(Data_temp[,-1], starts_with("J"))))/4

#计算子指数
Results_city_2_ETVI=(Results_city_2_Exposure*Results_city_2_Sensitivity*(100-Results_city_2_Adaptive))^(1/3)

#合并数据
Results_City_2_detail=cbind(Data_temp,Results_city_2_Exposure,Results_city_2_Sensitivity,Results_city_2_Adaptive,Results_city_2_ETVI)

#重命名数据
colnames(Results_City_2_detail)[(length(Results_City_2_detail)-3):length(Results_City_2_detail)]=c("Results_city_2_Exposure","Results_city_2_Sensitivity","Results_city_2_Adaptive","Results_city_2_ETVI")

# #-----------------
# #将中文城市名称转化为英文
# #-----------------
# 
# for (i in 1:dim(Results_City_2_detail)[1]) {
#   Results_City_2_detail$城市[i]<-city_name_list$English_Name[city_name_list$Chinese_Name==Results_City_2_detail$城市[i]]
# }

#保存数据
write.csv(Results_City_2_detail, "Results_City_2_detail.csv", fileEncoding = "GBK",row.names = F)

# library("xlsx")
# write.xlsx(Results_City_2_detail, "Results_City_2_detail.xlsx", sheetName = "Sheet1", 
#            col.names = TRUE, row.names = F, append = T)

##################----------------------------------------------------------------###############
##################----------------------2.1.城市层面每年--------------------------###############
##################----------------------------------------------------------------###############



#----------城市指数的构建------------#------------------------------------（每5年一个指数）

#定义城市数据，方便操作
Data_select_城市 = Data_select


#-----B 理论框架加总----- （根据具体情况，调整）

#计算中位数
Data_temp<-Data_select_城市

#生成子指标
Results_city_2_Exposure=(rowMeans(select(Data_temp[,-1], starts_with("A")))+rowMeans(select(Data_temp[,-1], starts_with("B"))))/2
Results_city_2_Sensitivity=(rowMeans(select(Data_temp[,-1], starts_with("C")))+rowMeans(select(Data_temp[,-1], starts_with("D")))+rowMeans(select(Data_temp[,-1], starts_with("E")))+rowMeans(select(Data_temp[,-1], starts_with("F"))))/4
Results_city_2_Adaptive=(rowMeans(select(Data_temp[,-1], starts_with("G")))+rowMeans(select(Data_temp[,-1], starts_with("H")))+rowMeans(select(Data_temp[,-1], starts_with("I")))+rowMeans(select(Data_temp[,-1], starts_with("J"))))/4

#计算子指数
Results_city_2_ETVI=(Results_city_2_Exposure*Results_city_2_Sensitivity*(100-Results_city_2_Adaptive))^(1/3)

#合并数据
Results_City_2_detail=cbind(Data_temp,Results_city_2_Exposure,Results_city_2_Sensitivity,Results_city_2_Adaptive,Results_city_2_ETVI)

#重命名数据
colnames(Results_City_2_detail)[(length(Results_City_2_detail)-3):length(Results_City_2_detail)]=c("Results_city_2_Exposure","Results_city_2_Sensitivity","Results_city_2_Adaptive","Results_city_2_ETVI")


# #-----------------
# #将中文城市名称转化为英文
# #-----------------

# for (i in 1:dim(Results_City_2_detail)[1]) {
#   Results_City_2_detail$城市[i]<-city_name_list$English_Name[city_name_list$Chinese_Name==Results_City_2_detail$城市[i]]
# }

#保存数据
write.csv(Results_City_2_detail, "Results_City_2_disagreegate.csv", fileEncoding = "GBK",row.names = F)




